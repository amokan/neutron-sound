﻿
param($dir = "C:\Other\AKWF\AKWF_0001")

$sox = 'C:\"Program Files (x86)"\sox-14-4-1\sox.exe'



$codefilename = 'const int16_t #WAVNAME#[] = {'



<#


http://sourceforge.net/projects/sox/files/sox/

37632


#>

function WavToDat($filepath)
{
    $args = "/c $sox $($filepath) -r 37632 $($filepath.Replace('.wav', '.dat'))"

    #write-host "cmd $args "
    start-process cmd.exe -wait -ArgumentList $args -NoNewWindow 

}



function ConvertDir ($dir)
{
    $files = dir $dir | where {$_.Fullname -like "*.wav"}

    foreach ($file in $files) 
    { 
        $name = $file.basename
        write-host "Converting $($file.basename)...."
        WavToDat $file.FullName
        ConvertDatToTxt $file.fullname.Replace('.wav', '.dat') $name

        if ((test-path $file.fullname.Replace('.wav', '.dat')) -eq $true)
        {
            Remove-Item $file.fullname.Replace('.wav', '.dat')
        }
    }

}



function ConvertDatToTxt($file, $name)
{
    $content = get-content $file

    $outfile = $file.Replace('.dat', '_int16_512.txt')

    if ((test-path $outfile) -eq $true)
    {
        Remove-Item $outfile -Force
    }

    $start = 2
    $width = 16
    $line = ""
    $data = @()

    $codefilename.Replace("#WAVNAME#", $name) >> $outfile

    for ($i=$start; $i -lt $content.Length ; $i++)
    {
        $line = ($content[$i] -replace '\s+', ' ').Trim()
        $float = [float]$line.Split(' ')[1]
        $data += [int]($float * 32767)
        
        if ($data.length -eq $width)
        {    
            if ($i -eq $content.Length-1){$c=""}else{$c=","}

            "    $($data -join ',')$c" >> $outfile
            $data = @()
        }
    } 


    if ($data.length -ne 0)
    {    
            
        "$($data -join ',')" >> $outfile
        $data = @()
    }

    "};" >> $outfile

}


ConvertDir

